package com.example.kkl

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.net.PasswordAuthentication

class MainActivity : AppCompatActivity() {




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
     /*   var name = findViewById<EditText>(R.id.user_name)
        var password = findViewById<EditText>(R.id.password)
        var login = findViewById<Button>(R.id.login)
        var create = findViewById<TextView>(R.id.sign_up)






        create.setOnClickListener {
            var i = Intent (this,next::class.java)
            startActivity(i)
        }
        login.setOnClickListener {
            if (name.text.isEmpty())
                Toast.makeText(this,"Enter Your name" , Toast.LENGTH_LONG).show()
            else if (password.text.isEmpty())
                Toast.makeText(this,"Enter you password",Toast.LENGTH_SHORT).show()
            else
            {
                var i = Intent(this,home::class.java)
                i.putExtra("name",name.text.toString())
                i.putExtra("password",password.text.toString())
                startActivity(i)
                finish()
            }
        }*/

    /*    click = findViewById(R.id.button)

        roll = findViewById(R.id.button4)




        Toast.makeText(this,"kimo",Toast.LENGTH_LONG).show()

        click.setOnClickListener{
                var i = Intent(this,MainActivity2::class.java)
            startActivity(i)
            }
        roll.setOnClickListener {
            var intent = Intent(this,MainActivity4::class.java)
            startActivity(intent)
        }*/
        /*
        var username = findViewById<EditText>(R.id.username)
        var pass = findViewById<EditText>(R.id.password)
        var btn = findViewById<Button>(R.id.button)
        var sing = findViewById<TextView>(R.id.textView4)

        btn.setOnClickListener {
            if (username.text.isEmpty() && pass.text.isEmpty())
                Toast.makeText(this , " Enter your data",Toast.LENGTH_SHORT).show()
            else if (username.text.isEmpty())
                Toast.makeText(this,"Enter your usename",Toast.LENGTH_SHORT).show()
            else if (pass.text.isEmpty())
                Toast.makeText(this , "Enter your password" , Toast.LENGTH_SHORT).show()
            else {
                var i = Intent(this, home::class.java)
                i.putExtra("name", username.text.toString())
                i.putExtra("pass",pass.text.toString())
                startActivity(i)
            }

        }

       sing.setOnClickListener {
           var i = Intent(this,next::class.java)

           startActivity(i)

       }*/




        







        





    }
}