package com.example.kkl

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        var name = findViewById<EditText>(R.id.editTextTextPersonName2)
        var password = findViewById<EditText>(R.id.editTextTextPassword)
        var email = findViewById<EditText>(R.id.editTextTextEmailAddress)
        var phone = findViewById<EditText>(R.id.editTextPhone)
        var button = findViewById<Button>(R.id.button2)

        Toast.makeText(this,"kkkkkk",Toast.LENGTH_SHORT).show()

        button.setOnClickListener{
            if (name.text.isEmpty()&& password.text.isEmpty() && email.text.isEmpty() && phone.text.isEmpty())
            {
                Toast.makeText(this,"enter your data",Toast.LENGTH_SHORT).show()
            }
            else if (password.text.isEmpty())
            {
                Toast.makeText(this,"enter your password",Toast.LENGTH_SHORT).show()
            }
            //error here
            else if (password.text.toString().length==8)
            {
                Toast.makeText(this,"please enter 8 charcters in password",Toast.LENGTH_SHORT).show()
            }
            //to here
            else if (email.text.isEmpty())
            {
                Toast.makeText(this,"enter your email",Toast.LENGTH_SHORT).show()
            }
            else if (phone.text.isEmpty())
            {
                Toast.makeText(this,"enter your phone",Toast.LENGTH_SHORT).show()
            }

            else {
                var i = Intent(this, MainActivity3::class.java)
                i.putExtra("username",name.text.toString())
                i.putExtra("email",email.text.toString())
                startActivity(i)
            }

        }


    }
}