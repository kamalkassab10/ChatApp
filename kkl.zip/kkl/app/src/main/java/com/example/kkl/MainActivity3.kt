package com.example.kkl

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class MainActivity3 : AppCompatActivity() {
    lateinit var rv_massege :RecyclerView
    lateinit var edt_massege :EditText
    lateinit var btn_add:Button
    var userlist :ArrayList<user> = ArrayList()
    var username:String?=null
    var email:String?= null
    val Userrecyclerview:userrecyclerview by lazy {
        userrecyclerview()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        if (intent !=null)
        {
            username = intent.extras !!.get("username").toString()
            email = intent.extras!!.get("email").toString()
            Toast.makeText(this,"user name is : $username",Toast.LENGTH_SHORT).show()
        }

        rv_massege = findViewById(R.id.rv_show)
        edt_massege = findViewById(R.id.editTextTextPersonName3)
        btn_add = findViewById(R.id.button3)

        rv_massege.adapter = Userrecyclerview


        btn_add.setOnClickListener{
            userlist.add(user(1,"Name : ",username.toString(),"Email : ",email.toString(),edt_massege.text.toString(),R.drawable.a))
            Userrecyclerview.set_list(userlist)
            edt_massege.setText("")

        }





    }
}