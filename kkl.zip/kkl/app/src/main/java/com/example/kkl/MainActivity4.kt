package com.example.kkl

import android.media.MediaPlayer
import android.nfc.Tag
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import java.util.*
import kotlin.random.Random

class MainActivity4 : AppCompatActivity() {
    lateinit var roll:Button
    lateinit var img:ImageView
    var i = 0
    lateinit var cont:TextView
    lateinit var con :TextView

    var s = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)
        roll = findViewById(R.id.button5)
        img= findViewById(R.id.imageView)
        cont = findViewById(R.id.textView)
        con = findViewById(R.id.textView2)



        roll.setOnClickListener {
            var rand = Random.nextInt(1,6)
            var drow = when (rand) {
                1->R.drawable.one
                2->R.drawable.tow
                3->R.drawable.three
                4->R.drawable.four
                5->R.drawable.five
                else ->R.drawable.sex

            }
            s=s+1
            if (rand==1)
                i=1
            else if (rand ==2)
                i=2
            else if (rand ==3)
                i=3
            else if (rand ==4)
                i=4
            else if (rand ==5)
                i=5
            else
                i=6


            img.setImageResource(drow)



            cont.setText("R = $i")
            con.setText("Many of Rolls is : $s")

        }

    }
}