package com.example.kkl.database

import androidx.room.RoomDatabase

abstract class DataBase: RoomDatabase() {
}