package com.example.kkl.database

import androidx.room.*
import com.example.kkl.user

@Dao
interface userDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun add_or_updata_user(user: user)
    @Delete
    fun del_user(user: user)
    @Query ("Select * from user_table")
    fun get_user():List<user>
}