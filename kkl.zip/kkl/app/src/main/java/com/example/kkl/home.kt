package com.example.kkl

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.TextView

class home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        var name = findViewById<TextView>(R.id.textView4)
        var password = findViewById<TextView>(R.id.textView7)
        var intent_name:String
        var intent_password :String
        intent_name = intent.extras!!.get("name").toString()


        intent_password = intent.extras!!.get("password").toString()


        name.setText(intent_name.toString())
        password.setText(intent_password.toString())

        var intent = Intent(this , thanks::class.java)
        Handler().postDelayed({
            startActivity(intent)
            finish()
        }, 8000)
    }
}