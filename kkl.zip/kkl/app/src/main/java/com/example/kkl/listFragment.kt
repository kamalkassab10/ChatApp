package com.example.kkl

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.kkl.databinding.FragmentListBinding

class listFragment : Fragment() , onListItemClick {
    lateinit var binding :FragmentListBinding
    var userlist :ArrayList<user> = ArrayList()
    var username:String?=null
    var email:String?= null
    val UserRecyclerView:userrecyclerview by lazy {
        userrecyclerview()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentListBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
       /* if (intent !=null)
        {
            username = intent.extras !!.get("username").toString()
            email = intent.extras!!.get("email").toString()
            Toast.makeText(this,"user name is : $username",Toast.LENGTH_SHORT).show()
        }*/
        username = arguments?.getString("userName")




       binding.rvShow.adapter = UserRecyclerView
       binding.button3.setOnClickListener{
            userlist.add(user(1,"Name : ",username.toString(),"Email : ",email.toString(),binding.editTextTextPersonName3.text.toString(),R.drawable.a))
            UserRecyclerView.set_list(userlist)
            binding.editTextTextPersonName3.setText("")

        }
        UserRecyclerView.ItemCLick = this
    }


    override fun onItemClick(user: user) {
        Toast.makeText(
            context,
            "The UserName is : ${user.name_en}\n The Email is :${user.email_en}\n The Message is : ${user.message}",
            Toast.LENGTH_SHORT).show()


    }


}