package com.example.kkl

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.kkl.databinding.FragmentLoginBinding

class loginFragment : Fragment() {
    lateinit var binding: FragmentLoginBinding
    lateinit var userName:String
    lateinit var email :String



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding= FragmentLoginBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.signUp.setOnClickListener {
            /*var i = Intent (this,next::class.java)
            startActivity(i)*/
            findNavController().navigate(R.id.action_loginFragment_to_rollFragment)
        }
        binding.login.setOnClickListener {
            if (binding.userName.text.isEmpty())
                Toast.makeText(context,"Enter Your name" , Toast.LENGTH_LONG).show()
            else if (binding.password.text.isEmpty())
                Toast.makeText(context,"Enter you password", Toast.LENGTH_SHORT).show()
            else
            {
              /*  var i = Intent(this,home::class.java)
                i.putExtra("name",name.text.toString())
                i.putExtra("password",password.text.toString())
                startActivity(i)
                finish()*/
                    userName = binding.userName.text.toString()
                email = binding.password.text.toString()
                    var action = loginFragmentDirections.actionLoginFragmentToListFragment(userName)



                findNavController().navigate(action)
            }
        }



    }


}