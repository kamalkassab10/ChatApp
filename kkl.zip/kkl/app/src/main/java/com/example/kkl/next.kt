package com.example.kkl

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class next : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_next)
        var name = findViewById<EditText>(R.id.user_name_sign)
        var email = findViewById<EditText>(R.id.user_email_sign)
        var pass = findViewById<EditText>(R.id.password_sign)
        var phone = findViewById<EditText>(R.id.phone_sign)
        var sign = findViewById<Button>(R.id.btn_sign_up)
        sign.setOnClickListener {
            if (name.text.isEmpty())
                Toast.makeText(this,"Enter your name" , Toast.LENGTH_SHORT).show()
            else if (email.text.isEmpty())
                Toast.makeText(this,"Enter your email" , Toast.LENGTH_SHORT).show()
            else if (pass.text.isEmpty())
                Toast.makeText(this,"Enter your password" , Toast.LENGTH_SHORT).show()
            else if (phone.text.isEmpty())
                Toast.makeText(this,"Enter your phone" , Toast.LENGTH_SHORT).show()
            else
            {
                var i = Intent(this,home::class.java)
                i.putExtra("name",name.text.toString())
                i.putExtra("password",pass.text.toString())
                startActivity(i)
                finish()
            }



        }



    }
}