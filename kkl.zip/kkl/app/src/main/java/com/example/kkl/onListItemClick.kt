package com.example.kkl

interface onListItemClick {
    fun onItemClick(user: user)
}