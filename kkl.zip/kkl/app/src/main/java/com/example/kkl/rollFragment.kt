package com.example.kkl

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.kkl.databinding.FragmentRollBinding
import kotlin.random.Random

class rollFragment : Fragment() {
    lateinit var binding:FragmentRollBinding
    var i =0
    var s =0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentRollBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.button5.setOnClickListener {
            var rand = Random.nextInt(1,6)
            var drow = when (rand) {
                1->R.drawable.one
                2->R.drawable.tow
                3->R.drawable.three
                4->R.drawable.four
                5->R.drawable.five
                else ->R.drawable.sex

            }
            s=s+1
            if (rand==1)
                i=1
            else if (rand ==2)
                i=2
            else if (rand ==3)
                i=3
            else if (rand ==4)
                i=4
            else if (rand ==5)
                i=5
            else
                i=6


            binding.imageView.setImageResource(drow)



            binding.textView.setText("R = $i")
            binding.textView2.setText("Many of Rolls is : $s")

        }

    }
    }


