package com.example.kkl

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.TestLooperManager
import android.widget.TextView
import androidx.core.graphics.rotationMatrix

class thanks : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_thanks)

        var i = Intent(this,MainActivity::class.java)
        Handler().postDelayed(
            {
                startActivity(i)
                finish()
            },4000)


    }
}