package com.example.kkl

import androidx.room.Entity
import androidx.room.PrimaryKey

//@Entity(tableName = "user_table")

data class user(
   // @PrimaryKey(autoGenerate = true)
    var id:Int,
    var name:String ,
    var name_en:String ,
    var email:String ,
    var email_en:String ,
    var message:String ,
    var img_id:Int
    )