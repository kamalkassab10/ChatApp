package com.example.kkl

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class userrecyclerview: RecyclerView.Adapter<userrecyclerview.userviewholder>() {
    var ItemCLick :onListItemClick?= null
    var user_list:ArrayList<user> = ArrayList()
    fun set_list (user_list :ArrayList<user>)
    {
        this.user_list= user_list
        notifyDataSetChanged()
    }

    inner class userviewholder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var img :ImageView=itemView.findViewById(R.id.item_img)
        var name :TextView = itemView.findViewById(R.id.item_name)
        var name_enter :TextView = itemView.findViewById(R.id.item_name_enter)
        var email :TextView = itemView.findViewById(R.id.item_email)
        var email_enter :TextView = itemView.findViewById(R.id.item_email_enter)
        var message :TextView = itemView.findViewById(R.id.item_message)
        fun bind (user: user)
        {

            img.setImageResource(user.img_id)
            name.text= user.name
            name_enter.text=user.name_en
            email.text=user.email
            email_enter.text=user.email_en
            message.text=user.message
            itemView.setOnClickListener {
                ItemCLick?.onItemClick(user)
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): userviewholder {
        var view:View = LayoutInflater.from(parent.context).inflate(R.layout.item_list,parent,false)
        return userviewholder(view)
    }

    override fun onBindViewHolder(holder: userviewholder, position: Int) {
        var user:user = user_list.get(position)
        holder.bind(user)

    }

    override fun getItemCount(): Int {
        return user_list.size

    }
}